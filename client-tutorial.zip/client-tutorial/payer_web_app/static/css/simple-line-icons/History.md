2.4.0 / 2016-09-18
==================

  * Add social-steam icon
  * Rename vkontakte to social-vkontakte icon

2.3.3 / 2016-09-17
==================

  * Add event icon, fix #57
  * Add vkontakte icon, fix #56

2.3.2 / 2016-06-13
==================

  * Add exclamation icon, fix #50
  * Use woff2, ttf, woff, svg order.

2.3.1 / 2016-05-04
==================

  * CSS, use woff before ttf
  * CSS, google instead of gplus
  * Gitignore, ignore .files
  * CSS, add organization, update readme
  * Add organization icon, fix #45
